//-------------------- Final Edit 
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <stdlib.h>
#include "md5.h"
#include "md5.cpp"
using namespace std;

int countClients();

struct Client {     //client struct
	int id;
	string fname;
	string lname;
	string pass;
	string address;
	string tel;
    string *otherInfo;  
};

Client client_table[100];       // client table
int size_client_table = -1;

bool idcheck(int id) {      // check if ID is already taken
	for (int i = 0; i < size_client_table; i++) {
		if (client_table[i].id == id)
			return false;
	}
	return true;
}

bool passverif(string mp) {     //password verification
	bool test_length = false;
	bool test_specialchar = false;
	bool test_alpha = false;
	bool test_digit = false;
    
	if (mp.length() > 9){   //length check
		test_length = true;
    }
	
    string  s = "-$#%@&*!"; 
    for(int i=0; i<mp.length();i++)
    {
        if(mp.find(s[i])<=mp.length())
        {
            test_specialchar = true;
        }
    }

    for(int i=0; i<mp.length();i++)
    {
		if((mp[i] >= 'A' && mp[i] <= 'z'))
		{
			test_alpha = true;
		}    
	}
    
	for(int i=0; i<mp.length();i++)
    {
		if((mp[i] >= 48 && mp[i] <= 57))
		{
			test_digit = true;
		}    
	}

	if(test_length && test_alpha && test_digit && test_specialchar){
		return true;
	}
}

bool emailverif(string email)
{
	// Check the first character
	// is an alphabet or not
	char c = email[0];
	if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {

		// If it's not an alphabet
		// email id is not valid
		return 0;
	}
	// Variable to store position
	// of At and Dot
	int At = -1, Dot = -1;

	// Traverse over the email id
	// string to find position of
	// Dot and At
	for (int i = 0; i < email.length(); i++) {

		// If the character is '@'
		if (email[i] == '@') {

			At = i;
		}

		// If character is '.'
		else if (email[i] == '.') {

			Dot = i;
		}
	}

	// If At or Dot is not present
	if (At == -1 || Dot == -1)
		return 0;

	// If Dot is present before At
	if (At > Dot)
		return 0;

	// If Dot is present at the end
	return !(Dot >= (email.length() - 1));
}

bool numbcompatible(string numb) {             //if the phone number is compatible
    for (int i = 0; i < numb.length(); i++) {
        if (isdigit(numb[i]) == 0 || numb.length() != 8)
            return 0;
    }
    return 1;
}

void addCLient(Client c) {                  //adding patients in tablePatient
	client_table[size_client_table].id = c.id;
	client_table[size_client_table].address = c.address;
	client_table[size_client_table].fname = c.fname;
	client_table[size_client_table].lname = c.lname;
	client_table[size_client_table].pass = c.pass;
	client_table[size_client_table].tel = c.tel;
	size_client_table++;
}

void saveClients() {           //adding clients info in client.txt
	MD5 hash;
	ofstream ofsP;
	ofsP.open("client.txt", ios::app);
	if (!ofsP.is_open())
	{
		cout << "error openning client.txt!";
	}
	ofstream clearFiles;
	clearFiles.open("client.txt");
	clearFiles << "";
	for (int i = 0; i < size_client_table; i++)
	{
		ofsP << client_table[i].id << " " << client_table[i].fname << " " << client_table[i].lname << " " << hash(client_table[i].pass) << " " << client_table[i].address << " " << client_table[i].tel << endl;
	}
	ofsP.clear();
	ofsP.close();
}

void refreshClient() {
	ifstream ifs;
	ifs.open("client.txt");
	while (ifs) {
		size_client_table++;
		ifs >> client_table[size_client_table].id;
		ifs >> client_table[size_client_table].fname;
		ifs >> client_table[size_client_table].lname;
		ifs >> client_table[size_client_table].pass;
		ifs >> client_table[size_client_table].address;
		ifs >> client_table[size_client_table].tel;
	}
}

bool login(Client* c, string email, string passwd) {      //check email and pass if it exists in client_table
    MD5 hash;
    for (int i = 0; i < countClients(); i++) {
        if (c[i].address == email && c[i].pass == hash(passwd) )
        return 1;
    }
    return 0;
}

struct Products {
	int id;
	string nom;
	double prix;
    string type;
};

Products products_table[100];
int size_products_table = -1;

void addProducts(Products prd) {        // add products to products_table
	products_table[size_products_table].id = prd.id;
	products_table[size_products_table].nom = prd.nom;
	products_table[size_products_table].prix = prd.prix;
	products_table[size_products_table].type = prd.type;
	size_products_table++;
}

void saveProducts() {         // add products info in produit.txt
	ofstream ofsL;
	ofsL.open("produit.txt", ios::app);
	if (!ofsL.is_open())
	{
		cout << "Le fichier produit est introuvable !";
	}
	ofstream clearFiles;
	clearFiles.open("produit.txt");
	clearFiles << "";
	for (int i = 0; i < size_products_table; i++)
	{
		ofsL << products_table[i].id << " " << products_table[i].nom << " "<< products_table[i].prix << " "<< products_table[i].type<< endl;
	}
	ofsL.clear();
	ofsL.close();
}

void refreshProducts() {
	ifstream ifs;
	ifs.open("produit.txt");
	while (ifs) {
		size_products_table++;
		ifs >> products_table[size_products_table].id;
		ifs >> products_table[size_products_table].nom;
		ifs >> products_table[size_products_table].prix;
		ifs >> products_table[size_products_table].type;
	}
}

void deleteProducts(int id) {      // delete products
	for (int i = 0; i < size_products_table; i++)
	if (id == products_table[i].id) {
		for (int j = i; j < size_products_table; j++) {
			products_table[j] = products_table[j + 1];
		}
        size_products_table--;
	}
}

void deleteClients(int id) {      // delete clients
	for (int i = 0; i < size_client_table; i++)
	if (client_table[i].id == id) {
		for (int j = i; j < size_client_table; j++) {
			client_table[j] = client_table[j + 1];
		}
        size_client_table--;
	}
}

string retreive_product_ename(int id) {
	for (int i = 0; i < size_products_table; i++) {
		if (products_table[i].id == id)
		return products_table[i].nom;
	}
}

double retreive_product_price(int id) {
	for (int i = 0; i < size_products_table; i++) {
		if (products_table[i].id == id)
		return products_table[i].prix;
	}
}

string retreive_client_fname(string email) {
	for (int i = 0; i < size_client_table; i++) {
		if (client_table[i].address == email)
		return client_table[i].fname;
	}
}

string retreive_client_lname(string email) {
	for (int i = 0; i < size_client_table; i++) {
		if (client_table[i].address == email)
		return client_table[i].lname;
	}
}

void Display_Products() {
    ifstream prod("produit.txt");
    prod.open("produit.txt", ios::out | ios::app);
    if (prod.is_open()) {
        std::cout << prod.rdbuf();
    }
}

void Display_Clients() {
    ifstream prod("client.txt");
    prod.open("client.txt", ios::out | ios::app);
    if (prod.is_open()) {
        std::cout << prod.rdbuf();
    }
}

struct Reciept {     // reciept struct
	string client_fname;
	string client_lname;
    double total;  
};

Reciept reciept_table[100];       // reciept table
int size_reciept_table = -1;

void addReciept(Reciept r1) {                  //adding in reciept table
	reciept_table[size_reciept_table].client_fname = r1.client_fname;
	reciept_table[size_reciept_table].client_lname = r1.client_lname;
	reciept_table[size_reciept_table].total = r1.total;
	size_reciept_table++;
}

void write_Reciept(Reciept r1) {
	fstream f("reciept.csv", ios::out | ios::app);
	f <<  r1.client_fname << "," << r1.client_lname << "," << r1.total << endl;
}

int countClients(){
    fstream f;
    f.open("client.txt", ios::in);
    string id,fname,lname,pass,email,tel;
    int count = 0;
    while (f){
        f>>id>>fname>>lname>>pass>>email>>tel;
        if (f){
            count++;
        }
    }
    f.close();
    return count;
}
 
Client* fillClients(){
    int numberOfClients = countClients();
    Client* c = new Client[numberOfClients];
    fstream f;
    f.open("client.txt", ios::in);
    int index = 0;
    string id,fname,lname,pass,email,tel;
    while (f){
        f>>id>>fname>>lname>>pass>>email>>tel;    
        if ( f ){
            int idtmp;
            stringstream ss; 
            ss<<id;
            ss>>idtmp;
            c[index].id = idtmp;
            c[index].fname = fname;
            c[index].lname = lname;
            c[index].pass = pass;
            c[index].address = email;
            c[index].tel = tel;
            index++;
        }
    }
    f.close();
    return c;
}

/* 
void trierordrecroissant(Reciept reciept_table[], int n) {        
    Reciept t1;
    for (int i = 0; i < n / 2; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (t[j].prix > t[j + 1].prix) {
                t1 = t[j];
                t[j] = t[j + 1];
                t[j + 1] = t1;
            }
        }
    }
}
*/

int main()
{   
	refreshClient();
	refreshProducts();
    cout << "----------------WELCOME BACK-------------------\n";
	int choix;
    cout << "1- Sign in\n2- Log in\n0- Leave\n";
	cin >> choix;
	if (choix == 0)     //quit
    {
		return 0;
	} 
	else if (choix == 1)        //creating account
    {  	
		cout << "-------------------SIGN IN-------------------\n";
        Client c;
		srand(time(NULL));
        int id = rand();
		while (!idcheck(id)) {
			srand(time(NULL));
			id = rand();
		}
		c.id = id;   //id
 
        string prenom, nom, mp, email, other, telephone;
        cout << "Prenom: ";
		cin >> prenom;
		c.fname = prenom; // fname

		cout << "Nom: ";
		cin >> nom;
		c.lname = nom;  //lname
		
        cout << "Mot de Passe: ";
		cin >> mp;
		while (!passverif(mp)) {    //email verification
			cout << "pass non valide!!\n";
			cout << "mot de passe: ";
			cin >> mp;
		}

		c.pass = mp;  // pass
        
        cout << "Email: ";
		cin >> email;
		while (!emailverif(email)) {    //email verification
			cout << "email non valide!!\n";
			cout << "email: ";
			cin >> email;
		}

		c.address = email;  //email

        cout << "Telephone: ";
		cin >> telephone;
		while (!numbcompatible(telephone)) {    //email verification
			cout << "numero non valide!!\n";
			cout << "telephone: ";
			cin >> telephone;
		}
        c.tel = telephone;  //telephone
        
        addCLient(c); // adding to struct
        saveClients(); // saving in client.txt
    }    
	refreshClient();
	cout << "--------------------LOG IN----------------------\n";
	string email, password;
    cout << "Email: ";
	cin >> email;
	cout << "Password: ";
	cin >> password;
	cout << "-------------------------------------------------\n";
	if (email == "admin" && password == "admin") { // admin

		cout << "1- Ajouter un produit\n2- Supprimer un produit\n3- Ajouter un client\n4- Supprimer un client\n";
		int choix;
		cin >> choix;
		if (choix == 1) {  // add products
			
			srand(time(NULL));
			int id = rand();
			while (!idcheck(id)) {
				srand(time(NULL));
				id = rand();
			}
			
			cin.ignore(INT_MAX,'\n');
			string type, nom;
        	double prix;
            cout << "Type: ";
			getline(cin,type);
			cin.ignore(INT_MAX,'\n');			
			
			cout << "Nom: ";
            getline(cin,nom);
			cin.ignore(INT_MAX,'\n'); //clear buffer before taking new line
            
			cout << "prix: ";
			cin >> prix;
			
            Products prd;
			prd.id = id;
			prd.nom = nom;
			prd.prix = prix;
			prd.type = type;
            
			addProducts(prd);
			saveProducts();
			refreshProducts();
		} 
		else if (choix == 2) // delete products
        {   
			refreshProducts();
			Display_Products();
			cout << endl <<"Choisie le id a supprimer: ";
			int supid;
			cin >> supid;
			deleteProducts(supid);
			saveProducts();
			refreshProducts();
			cout << "Le produit numero " << supid <<" est supprimer." << endl;
		}
		else if (choix == 3) // add client
        {   
            Client c1;
		    srand(time(NULL));
            int id = rand();
		
            while (!idcheck(id)) 
            {
			    srand(time(NULL));
			    id = rand();
		    }
		        
            c1.id = id;
		
            string prenom, nom, mp, telephone, email, other;
            cout << "Prenom: ";
            cin >> prenom;
            c1.fname = prenom;

            cout << "Nom: ";
            cin >> nom;
            c1.lname = nom;

            cout << "mot de passe: ";
            cin >> mp;
            while (!passverif(mp)) {        //pass verification
                cout << "le mots de passe doit : longueur doit etre d'au moins 8, tout en contenant des chiffres, des lettres et des caract?res sp?ciaux!!\n";
                cout << "mot de passe: ";
                cin >> mp;
            }
            c1.pass = mp;
            
            cout << "email: ";;
            cin >> email;
            while (!emailverif(email)) {    //email verification
                cout << "email non valide!!\n";
                cout << "email: ";
                cin >> email;
            }
            c1.address = email;
            
            cout << "telephone: ";
			cin >> telephone;
			
			while (!numbcompatible(telephone)) {    //telephone verification
			cout << "numero non valide!!\n";
			cout << "telephone: ";
			cin >> telephone;
			}
            c1.tel = telephone;

            addCLient(c1);
            saveClients();
			refreshClient();

			cout << endl <<"Le Client " << c1.fname << " " << c1.lname << " est ajouter." << endl;
        }
        else if (choix == 4) // delete client
        {   
			refreshClient();
			Display_Clients();
			cout << "Choisie le id a supprimer: ";
			int supid;
			cin >> supid;
			deleteClients(supid);
			saveClients();
			refreshClient();
			cout << "Le client numero " << supid <<" est supprimer." << endl;

		}
		 
	}
	else 
	{	
		Client* c = fillClients();
		int exist = login(c,email, password);
		if (exist == 1)  // client exists
		{
			cout << endl <<"--------------------ACHETER----------------------\n";

			Display_Products();
			cout << "Donner le nombre de produit different que vous voulez acheter : ";
			int nb = 0;
			cin >> nb;
			double s = 0.0;
			for (int i = 0; i < nb; i++)
			{
				cout << endl <<"Donner L'id du produit que vous voulez acheter : ";
				int idp;
				cin >> idp;
				cout << endl <<"Donner la quantite: ";
				int qty = 0;
				cin >> qty;
				s = s + retreive_product_price(idp)*qty;
				cout << endl <<"l'ID du produit choisit est : "<< idp <<" son nom est : "<< retreive_product_ename(idp) << " et son prix est : " << retreive_product_price(idp) <<"$" << endl;
			}
			
			cout << endl << "--------------------RECIEPT----------------------\n";

			cout << "le total est : " << s << " $" << endl;
			cout << "le nom du client est : "<<	retreive_client_fname(email) << " " << retreive_client_lname(email) << endl;		

			Reciept r1;
			
			r1.client_fname = retreive_client_fname(email);
			r1.client_lname = retreive_client_lname(email);
			r1.total = s;

			addReciept(r1);
			write_Reciept(r1);
		}
		else
		{ 
			cout << "le compte n'existe pas !!";
		}
		
	}
}
	
		
			
			

