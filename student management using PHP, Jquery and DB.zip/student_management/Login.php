<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <title>Sign in</title>
    <style>
        
       body{
            background-color: whitesmoke; 
            font-family: 'Roboto', sans-serif;
            width: 100%;
            font-size: 20px;
        }
            
        main{
            float: right;
            border: 1px solid gray;
            padding : 5px;
        }
        input{
            padding: 4px;
            border :2px solid black;
            text-align: center;
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
        }
        #add{
            padding: 2px;
            text-align: center;
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
            margin-top: 10px;
        }
    </style>   

</head>
<body>
<?php
    include("Connection.php");
    
    #button variable
    $username='';
    $password='';
?>    
<form method = 'POST'>
<div id ='div'>
    <img src='https://images.squarespace-cdn.com/content/v1/5b8f8acb2714e5d519fcaf81/1661173122028-A00BRQT69TDUHX0RHRED/Antonine+University+logo.png' alt='Error 404' width="300">
    <h3> Welcome back </h3>
    <label> Username : </label><br>
    <input type ='text' name='username' id='id'> <br>
    <label> Password : </label><br>
    <input type ='password' name='password' id='name'> <br>
    <button id = "add" name ='login'> Login </button>
</div>    

<?php
if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username == "admin" && $password == "admin") {
            header("location: home.php"); // redirect to home page
        } else {
            echo "<br>Wrong username or password!";
        }
    }

?>


</body>
</html>

