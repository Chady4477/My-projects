<?php
    include("Connection.php");  
    $res = mysqli_query($con,"Select * From student");
    
    #button variable
    $id='';
    $name='';
    $address='';
    if(isset($_POST['id'])){
        $id = $_POST['id'];
    }
    if(isset($_POST['name'])){
        $name = $_POST['name'];
    }
    if(isset($_POST['address'])){
        $address= $_POST['address'];
    }
    $sqls='';
    if(isset($_POST['add'])){
        $sqls = "Insert Into student Value($id,'$name','$address')";
        mysqli_query($con,$sqls);
        header("location: home.php"); // refresh
    }
    
    if(isset($_POST['del'])){
        $sqls = "Delete From student Where id = '$id' ";
        mysqli_query($con,$sqls);
        header("location: home.php"); // refresh
    }
    if(isset($_POST['update'])){
        $sqls = "UPDATE student set name='$name',address='$address'WHERE id=$id";
        mysqli_query($con,$sqls);
        header("location: home.php"); // refresh
    }
?>