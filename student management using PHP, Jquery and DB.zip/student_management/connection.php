<?php
    #database connection
    $host='localhost';
    $user='root';
    $pass='';
    $db='student1';
    $con = mysqli_connect($host,$user,$pass,$db); 
?>