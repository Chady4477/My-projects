<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width= , initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"> </script>
    <link href="css/style.css" rel="stylesheet">
    <style>
       body{
            background-color: whitesmoke; 
            font-family: 'Roboto', sans-serif;
        }

        #mother{
            width: 100%;
            font-size: 20px;
        }
        main{
            float: right;
            border: 1px solid gray;
            padding : 5px;
        }
        input{
            padding: 4px;
            border :2px solid black;
            text-align: center;
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
        }
        aside{
            text-align: center;
            width: 300px;
            float: left;
            border: 1px solid black;
            padding: 10px;
            font-size: 20px;
            background-color:silver;
            color: white;
            
        }
        #tbl{
            width: 890px;
            font-size: 20px;
            text-align: center;
        }
        #tbl th{
            background-color: silver;
            color: black;
            font-size: 20px;
            padding: 10px;
            text-align: center;
        }  
        aside button{
            width: 190px;
            padding: 8px;
            margin-top: 7px;
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
            font-weight: bold;
        }
    </style>   
    <title>Home</title>
</head>
<body>
<div id = 'mother'>
<form method = 'POST'>
<!-- Management Panel -->
<aside>
<div id ='div'>
    <img src='https://images.squarespace-cdn.com/content/v1/5b8f8acb2714e5d519fcaf81/1661173122028-A00BRQT69TDUHX0RHRED/Antonine+University+logo.png' alt='Error 404' width="300">
    <h3> Student Information System </h3>
    <label> Student Number : </label><br>
    <input type ='text' name='id' id='id'> <br>
    <label> Student Name : </label><br>
    <input type ='text' name='name' id='name'> <br>
    <label> Student Address : </label><br>
    <input type ='text' name='address' id='address'> <br><br>
    <button id = "add" name ='add'> Add Student </button>
    <button id = "del" name ='del'> Delete Student </button>
    <button id = "update" name ='update'> Update Student </button>
    <button id = "hide" name ='hide'> Hide </button>
</div>    
</aside>

<!-- Student's Data -->
<main>
    <table id = 'tbl'>
        <tr>
            <th> ID </th>
            <th> Name </th>
            <th> Address </th>
        </tr>
    
    <?php
        include("Connection.php");
        include("action.php");
        while ($row = mysqli_fetch_array($res) ) {
            echo "<tr>";
            echo "<td>".$row['id']."</td>";
            echo "<td>".$row['name']."</td>";
            echo "<td>".$row['address']."</td>";
            echo "</tr>";
        }
    ?>
    <label> Search Student Name : </label>
    <input type="text" id="Search" />
    </table>
</main>    
</body>
</html>

<script>
	$(document).ready(function(){
		$("#add").click(function(){   //add button
			alert("New Student Added!");
		}); 
        $("#del").click(function(){   //Delete button
			alert("Student Deleted!");
		});    
        $("#update").click(function(){   //Update button
			alert("Student Updated!");
		});   
        $("tr").click(function(){
			$(this).css("background-color", "yellow"); //coloring table rows
		});		     
        $("#hide").click(function(){             // hide table
			$("#tbl").hide();
		});     
        $("table").click(function(){         // bigger font size
			var div = $("table");
			div.animate({fontSize: '2em'},"slow");
		});       		
		$("#Search").on("keyup", function() {          //search for student
			var value = this.value.toLowerCase().trim();
			$("tr td").show().filter(function() {
				return $(this).text().toLowerCase().trim().indexOf(value);
			}).hide();
		});     
	});
</script>
