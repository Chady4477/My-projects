package in.library.springbootmongodb.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import in.library.springbootmongodb.exception.BookCollectionException;
import in.library.springbootmongodb.model.Book;
import in.library.springbootmongodb.service.LibraryService;
import jakarta.validation.ConstraintViolationException;

@RestController //RESTful web service controller.
public class LibraryController {
	
	// instances of library service.
	@Autowired
	private LibraryService LibraryService;
	

	@GetMapping("/books") //HTTP GET Requests
	public ResponseEntity<?> getAllBooks(){ //returns a ResponseEntity object that can contain any type of data
		List<Book> books = LibraryService.getAllBooks();
		return new ResponseEntity<>(books, books.size() > 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND);
	}

	@PostMapping("/books")//HTTP Post Requests
		public ResponseEntity<?> addBook(@RequestBody Book b){
			try {
				LibraryService.addBook(b);
				return new ResponseEntity<Book>(b, HttpStatus.OK); //added succesfully
			} catch(ConstraintViolationException e) {//Missing fields or invalid values
				return new ResponseEntity<>(e.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY);
			} catch (BookCollectionException e) {//conflict
				return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
			}
	}

	//Get specific book from the database
	@GetMapping("/books/{id}")//HTTP Get Request
	public ResponseEntity<?> getSingleBook(@PathVariable("id") String id){
		try {
			return new ResponseEntity<>(LibraryService.getSingleBook(id), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	//Update specific book from the database
	@PutMapping("/books/{id}")
	public ResponseEntity<?> updateById(@PathVariable("id") String id, @RequestBody Book b){
		try {
			LibraryService.updateById(id, b);
			return new ResponseEntity<>("Book successfully updated  with id " + id, HttpStatus.OK);
		} catch(ConstraintViolationException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY);
		} catch (BookCollectionException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

	}

	//Delete specific book from the database
	@DeleteMapping("/books/{id}")
	public ResponseEntity<?> deleteById(@PathVariable("id") String id) {
		try {
			LibraryService.deleteById(id);
			return new ResponseEntity<>("Book successfully deleted with id "+ id, HttpStatus.OK);
		} catch (BookCollectionException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
}


