package in.library.springbootmongodb.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.library.springbootmongodb.exception.BookCollectionException;
import in.library.springbootmongodb.model.Book;
import in.library.springbootmongodb.repository.BookRepository;
import jakarta.validation.ConstraintViolationException;

@Service
public class LibraryServiceImpl implements LibraryService {

	@Autowired
	//The @Autowired annotation is used to inject an instance of
	//the BookRepository interface into the bookrepo field. 
	//This means that when the LibraryService bean is created by 
	//the Spring container,
	//it will automatically create and inject an instance of the 
	//BookRepository interface,
	
	private BookRepository bookrepo; //bookrepo is an instance of BookRepository

	//overriding "addBook" function and tests if name already exists
	@Override
	public void addBook(Book b) throws ConstraintViolationException, BookCollectionException {
		Optional <Book> bookName = bookrepo.findByName(b.getName());
		if(bookName.isPresent()) {
			throw new BookCollectionException(BookCollectionException.BookAlreadyExists());
		}else {
			b.setCreatedAt(new Date(System.currentTimeMillis()));
			bookrepo.save(b);
		}
	}
	
	//overriding "getAllBooks" function to get the existing books in the database
	@Override
	public List<Book> getAllBooks(){
		List<Book> b = bookrepo.findAll();
		if(b.size() > 0) {
			return b;
		}else {
			return new ArrayList<Book>();
		}
	}

	//overriding "getSingleBook" function to get a specific book and checks if the ID exists
	@Override
	public Book getSingleBook(String id) throws BookCollectionException {
		Optional <Book> b = bookrepo.findById(id);
		if(!b.isPresent()) {
			throw new BookCollectionException(BookCollectionException.NotFoundException(id));
		}else {
			return b.get();
		}
	}

	//overriding "updateById" function and updates a specific book and it checks if the ID exists.
	@Override
	public void updateById(String id, Book b) throws BookCollectionException {
		Optional<Book> bookWithId = bookrepo.findById(id);
		Optional<Book> bookWithSameName = bookrepo.findByName(b.getName());
		
		if(bookWithId.isPresent()) {
			//if we update a book's  name to a name that already exists
			if(bookWithSameName.isPresent() && !bookWithSameName.get().getId().equals(id)) {
				throw new BookCollectionException(BookCollectionException.BookAlreadyExists());
			}
			//if ID found and the name does not already exists
			Book bookToUpdate = bookWithId.get();
			bookToUpdate.setName(b.getName()); 
			bookToUpdate.setDescription(b.getDescription());
			bookToUpdate.setavailable(b.getAvailable());
			bookToUpdate.setUpdatedAt(new Date(System.currentTimeMillis()));
			bookrepo.save(bookToUpdate);
		}else {
			//if ID not found
			throw new BookCollectionException(BookCollectionException.NotFoundException(id));
			
		}
		
	}

	//overriding "deleteById" function and deletes a specific book and it checks if the ID exists.
	@Override
	public void deleteById(String id) throws BookCollectionException {
		Optional<Book> bookName = bookrepo.findById(id);
		if(!bookName.isPresent()) {
			throw new BookCollectionException(BookCollectionException.NotFoundException(id));
		}else {
			bookrepo.deleteById(id);
		}
	}
}
