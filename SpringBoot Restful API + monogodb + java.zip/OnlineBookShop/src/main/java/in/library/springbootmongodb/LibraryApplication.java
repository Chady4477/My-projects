package in.library.springbootmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryApplication.class, args);
	}

	//SpringApplication class starts the Spring Boot application context, 
	//which initializes the necessary beans, such as controllers, services,
	//and repositories,
}
