package in.library.springbootmongodb.exception;

public class BookCollectionException extends Exception {

	private static final long serialVersionUID = 1L;
	

	//constructor for a custom exception class
	public BookCollectionException(String message){
		super(message);
	}
	
	//Creating exceptions..
	public static String NotFoundException(String id) {
		return "The book with the following id: " + id + " is not found";
	}
	
	public static String BookAlreadyExists() {
		return "The book with the given name already exists";
	}
}

//serialVersionUID is a field in Java that is used to provide a version 
//number for a serializable class. It is used during serialization and deserialization
//of objects to ensure that the correct version of the class is used.

//When an object is serialized, its data is converted into a stream of bytes that can be
//transmitted or stored. When the object is deserialized, the stream of bytes is
//converted back into an object. If the class of the serialized object has changed between
//serialization and deserialization, the deserialization process may fail or produce unexpected 
//results.

//To avoid this problem, Java provides the serialVersionUID field,
