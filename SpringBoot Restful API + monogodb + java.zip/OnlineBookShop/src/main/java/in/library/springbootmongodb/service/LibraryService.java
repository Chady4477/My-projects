package in.library.springbootmongodb.service;

import java.util.List;

import in.library.springbootmongodb.exception.BookCollectionException;
import in.library.springbootmongodb.model.Book;
import jakarta.validation.ConstraintViolationException;

public interface LibraryService {

	//function to add a new book into the database
	public void addBook(Book b) throws ConstraintViolationException, BookCollectionException;
	
	//function to get all the books from the database
	public List<Book> getAllBooks();
	
	//function to get a specific book from the database
	public Book getSingleBook(String id) throws BookCollectionException;
	
	//function to update a specific book from the database
	public void updateById(String id, Book b) throws BookCollectionException;
	
	//function to delete a specific book from the database
	public void deleteById(String id) throws BookCollectionException;
	
}
