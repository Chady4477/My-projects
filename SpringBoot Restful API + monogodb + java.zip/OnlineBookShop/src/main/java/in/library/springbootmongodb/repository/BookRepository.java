package in.library.springbootmongodb.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import in.library.springbootmongodb.model.Book;

@Repository
public interface BookRepository extends MongoRepository<Book, String> {
 //MongoRepository provides a set of generic CRUD (Create, Read, Update, and Delete)
	
 
 	//custom query method for finding a book by name in a MongoDB database.
	@Query("{'name':?0}")
	Optional <Book> findByName(String name);
	
}
