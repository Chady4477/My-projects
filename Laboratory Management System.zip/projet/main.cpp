#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <time.h> 
#include "md5.h"
#include "md5.cpp"

using namespace std;

struct date {
	int jour, mois, annee;
};

struct Time {
	int heure, minute, seconde;
};

struct Labotest {
	int id;
	string fname;
	string lname;
	string nom;
	double prix;
	bool cancelation, consultation;
	date test_date;
	Time test_time;
	string resultat;
};

struct Patient {
	int id;
	string fname;
	string lname;
	string pass;
	string address;
	string tel;
	Labotest* t;
};

Labotest tableLabotest[100];
int sizeLabotest = -1;
Patient tablePatient[100];
int sizePatient = -1;


// Function to check email id is
// valid or not
bool emailverif(string email)
{
	// Check the first character
	// is an alphabet or not
	char c = email[0];
	if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {

		// If it's not an alphabet
		// email id is not valid
		return 0;
	}
	// Variable to store position
	// of At and Dot
	int At = -1, Dot = -1;

	// Traverse over the email id
	// string to find position of
	// Dot and At
	for (int i = 0; i < email.length(); i++) {

		// If the character is '@'
		if (email[i] == '@') {

			At = i;
		}

		// If character is '.'
		else if (email[i] == '.') {

			Dot = i;
		}
	}

	// If At or Dot is not present
	if (At == -1 || Dot == -1)
		return 0;

	// If Dot is present before At
	if (At > Dot)
		return 0;

	// If Dot is present at the end
	return !(Dot >= (email.length() - 1));
}

bool passverif(string mp) {

	if (mp.length() < 8)   //length check
		return false;
	for (int i = 0; i < mp.length(); i++) {   //special characters check
		if (!(mp[i] >= 33 && mp[i] <= 125)) {
			return false;
		}
	}
	return true;
}

void clearFiles() // clearing files
{
	ofstream clearFiles;
	clearFiles.open("Patient.txt");
	clearFiles << "";
	clearFiles.close();
	clearFiles.open("Labtest.txt");
	clearFiles << "";
	clearFiles.close();
	clearFiles.open("Reservation.txt");
	clearFiles << "";
	clearFiles.close();
}

void refreshLabotest() {
	ifstream ifs;
	ifs.open("Labotest.txt");
	while (ifs) {
		sizeLabotest++;
		ifs >> tableLabotest[sizeLabotest].id;
		ifs >> tableLabotest[sizeLabotest].nom;
		ifs >> tableLabotest[sizeLabotest].prix;
		string canc1, canc2;
		ifs >> canc1;
		ifs >> canc2;
		if (canc1 == "free" && canc2 == "cancelation")
			tableLabotest[sizeLabotest].cancelation = true;
		else
			tableLabotest[sizeLabotest].cancelation = false;

		string cons1, cons2;
		ifs >> cons1;
		ifs >> cons2;
		if (cons1 == "free" && cons2 == "consultation")
			tableLabotest[sizeLabotest].consultation = true;
		else
			tableLabotest[sizeLabotest].consultation = false;
	}
}

void refreshPartient() {
	ifstream ifs;
	ifs.open("Patient.txt");
	while (ifs) {
		sizePatient++;
		ifs >> tablePatient[sizePatient].id;
		ifs >> tablePatient[sizePatient].fname;
		ifs >> tablePatient[sizePatient].lname;
		ifs >> tablePatient[sizePatient].pass;
		ifs >> tablePatient[sizePatient].address;
		ifs >> tablePatient[sizePatient].tel;
	}
}

void addPatient(Patient p) {                  //adding patients in tablePatient
	tablePatient[sizePatient].id = p.id;
	tablePatient[sizePatient].address = p.address;
	tablePatient[sizePatient].fname = p.fname;
	tablePatient[sizePatient].lname = p.lname;
	tablePatient[sizePatient].pass = p.pass;
	tablePatient[sizePatient].tel = p.tel;
	sizePatient++;
}

void savePatients() {           //adding patients info in patient.txt
	MD5 hash;
	ofstream ofsP;
	ofsP.open("Patient.txt", ios::app);
	if (!ofsP.is_open())
	{
		cout << "error openning patient!";
	}
	ofstream clearFiles;
	clearFiles.open("Patient.txt");
	clearFiles << "";
	for (int i = 0; i < sizePatient; i++)
	{
		ofsP << tablePatient[i].id << " " << tablePatient[i].fname << " " << tablePatient[i].lname << " " << hash(tablePatient[i].pass) << " " << tablePatient[i].address << " " << tablePatient[i].tel << endl;
	}
	ofsP.clear();
	ofsP.close();
}

void saveLabotest() {         // add labotest info in labostest.txt
	ofstream ofsL;
	ofsL.open("Labotest.txt", ios::app);
	if (!ofsL.is_open())
	{
		cout << "Le fichier Labotest est introuvable !";
	}
	ofstream clearFiles;
	clearFiles.open("Labotest.txt");
	clearFiles << "";
	for (int i = 0; i < sizeLabotest; i++)
	{
		ofsL << tableLabotest[i].id << " " << tableLabotest[i].nom << " " << tableLabotest[i].prix;
		if (tableLabotest[i].cancelation)
			ofsL << " free cancelation";
		else
			ofsL << "		";
		if (tableLabotest[i].consultation)
			ofsL << " free consultation";
		else
			ofsL << "		";
		ofsL << endl;
	}
	ofsL.clear();
	ofsL.close();

}
bool idcheck(int id) {              // check if ID is already taken
	for (int i = 0; i < sizePatient; i++) {
		if (tablePatient[i].id == id)
			return false;
	}
	return true;
}

void addLabotest(Labotest lt) {        // add info to tablelabotest
	tableLabotest[sizeLabotest].id = lt.id;
	tableLabotest[sizeLabotest].nom = lt.nom;
	tableLabotest[sizeLabotest].prix = lt.prix;
	tableLabotest[sizeLabotest].cancelation = lt.cancelation;
	tableLabotest[sizeLabotest].consultation = lt.consultation;
	sizeLabotest++;
}

int login(string e, string p) {      //check email and pass if it exists in tablePpatient
	MD5 hash;
	for (int i = 0; i < sizePatient; i++) {
		if (tablePatient[i].address == e && tablePatient[i].pass == hash(p))
			return tablePatient[i].id;
	}
	return -1;
}

void deletLabotest(int id) {      // delete labotest
	for (int i = 0; i < sizeLabotest; i++)
		if (id == tableLabotest[i].id) {
			for (int j = i; j < sizeLabotest; j++) {
				tableLabotest[j] = tableLabotest[j + 1];
			}
			sizeLabotest--;
		}
}


string retreiveFname(int);
string retreiveLname(int);
void displayApp(Labotest*);
int resCounter();
Labotest* readApp();
void writeReservation(Labotest);
void writeAllReservations(Labotest*);
void specificApp(string,string);
Labotest* deleteSpecApp(string,string,int,int);

int main() {
	refreshPartient();
	refreshLabotest();
	cout << "nouveau utilisateur ? \n1- oui\n2- non\n0- quitter\n";
	int choix;
	cin >> choix;
	int loginID;
	if (choix == 0) {
		return 0;
	}
	else if (choix == 1) {  //creation d'un compte
		Patient p;
		srand(time(NULL));
		int id = rand();
		while (!idcheck(id)) {
			srand(time(NULL));
			id = rand();
		}
		p.id = id;
		cout << "Prenom: ";
		string prenom;
		cin >> prenom;
		p.fname = prenom;

		cout << "Nom: ";
		string nom;
		cin >> nom;
		p.lname = nom;

		cout << "mot de passe: ";
		string mp;
		cin >> mp;
		while (!passverif(mp)) {        //pass verification
			cout << "le mots de passe doit suivre : longueur doit ?tre d'au moins 8, tout en contenant des chiffres, des lettres et des caract?res sp?ciaux!!\n";
			cout << "mot de passe: ";
			cin >> mp;
		}
		p.pass = mp;
		cout << "email: ";
		string email;
		cin >> email;
		while (!emailverif(email)) {    //email verification
			cout << "email non valide!!\n";
			cout << "email: ";
			cin >> email;
		}
		p.address = email;
		cout << "telephone: ";
		string telephone;
		cin >> telephone;
		p.tel = telephone;
		addPatient(p);
		savePatients();
	}
	cout << "-------------------------------------------------\n";
	cout << "Email: ";
	string email;
	cin >> email;
	cout << "Password: ";
	string password;
	cin >> password;
	loginID = login(email, password);
	if (loginID != -1)
	{
		if (loginID == 0) { // admin
			cout << "1- Ajoute\n2- Supprimer\n3- Modifier\n";
			int choix;
			cin >> choix;
			if (choix == 1) {  // ajouter test
				srand(time(NULL));
				int id = rand();
				while (!idcheck(id)) {
					srand(time(NULL));
					id = rand();
				}
				cout << "Type: ";
				string type;
				cin >> type;
				cout << "prix: ";
				double prix;
				cin >> prix;
				cout << "free cancelation ? 1-oui/2-non : ";
				int canc;
				cin >> canc;
				cout << "free consultation ? 1-oui/2-non : ";
				int cons;
				cin >> cons;
				Labotest lt;
				lt.id = id;
				lt.nom = type;
				lt.prix = prix;
				if (canc == 1)
					lt.cancelation = true;
				else
					lt.cancelation = false;
				if (cons == 1)
					lt.consultation = true;
				else
					lt.consultation = false;
				addLabotest(lt);
				saveLabotest();
			}
			else if (choix == 2) {   // delete test info
				for (int i = 0; i < sizeLabotest; i++)
					cout << tableLabotest[i].id << " " << tableLabotest[i].nom << endl;
				cout << "Choisie le id a supprimer: ";
				int supid;
				cin >> supid;
				deletLabotest(supid);
				saveLabotest();
			}
			else if (choix == 3) {   //update test info
				for (int i = 0; i < sizeLabotest; i++)
					cout << tableLabotest[i].id << " " << tableLabotest[i].nom << " " << tableLabotest[i].prix << endl;
				cout << "Choisie le id a modifier: ";
				int modid;
				cin >> modid;
				cout << "1-type\n2-prix\n";
				int c;
				cin >> c;
				if (c == 1) {
					cout << " nouveau type: ";
					for (int i = 0; i < sizeLabotest; i++)
						if (modid == tableLabotest[i].id) {
							string type2;
							cin >> type2;
							tableLabotest[i].nom = type2;
							break;
						}

				}
				else if (c == 2) {
					cout << " nouveau prix: ";
					for (int i = 0; i < sizeLabotest; i++)
						if (modid == tableLabotest[i].id) {
							double prix2;
							cin >> prix2;
							tableLabotest[i].prix = prix2;
							break;
						}
				}
				saveLabotest();

			}
		}
		else {         // patient
			cout << "1-Reserver un rdv\n2-annuler un rdv\n";
			int choix;
			cin >> choix;
			if (choix == 1) {  // request reservation 
				for (int i = 0; i < sizeLabotest; i++)
					cout << tableLabotest[i].id << " " << tableLabotest[i].nom << " " << tableLabotest[i].prix << endl;
					cout << "donner id du test du rdv: ";
					int idc;
					cin >> idc;
					cout << "choisir date:\njour: ";
					int j;
					cin >> j;
					cout << "mois: ";
					int mois;
					cin >> mois;
					cout << "annee: ";
					int an;
					cin >> an;
					cout << "heure pile: ";
					int h;
					cin >> h;

					Labotest lt;
					lt.id = idc;
					lt.fname = retreiveFname(loginID);
					lt.lname = retreiveLname(loginID);
					lt.test_date.jour = j;
					lt.test_date.mois = mois;
					lt.test_date.annee = an;
					lt.test_time.heure = h;
					lt.test_time.minute = 0;
					lt.test_time.seconde = 0;


					writeReservation(lt);


			}
			else if (choix == 2) {  // delete reservation
				cout << "These are your specific appointments :\n";
				string fname = retreiveFname(loginID);
				string lname = retreiveLname(loginID);
				specificApp(fname,lname);
				cout << "\nWhich appointment to delete : <ID> <DAY>     ";
				int id, day;
				cin >> id >> day;
				Labotest* cleaned = deleteSpecApp(fname,lname,day,id);
			}

		}

		return 0;
	}

	return 0;
}




void writeReservation(Labotest lt) {
	fstream f("Reservation.csv", ios::out | ios::app);
	f << lt.id << "," << lt.fname << "," << lt.lname << "," << lt.test_date.jour << "-" << lt.test_date.mois
		<< "-" << lt.test_date.annee << "," << lt.test_time.heure << ":" << lt.test_time.minute << ":" << lt.test_time.seconde << "\n";
}

string retreiveFname(int id) {
	for (int i = 0; i < sizePatient; i++) {
		if (tablePatient[i].id == id)
			return tablePatient[i].fname;
	}
}

string retreiveLname(int id) {
	for (int i = 0; i < sizePatient; i++) {
		if (tablePatient[i].id == id)
			return tablePatient[i].lname;
	}
}
void displayApp(Labotest* lt) {
	cout << lt->id << "\t" << lt->fname << "\t" << lt->lname << "\t" << lt->test_date.jour << "\t"
		<< lt->test_date.mois << "\t" << lt->test_date.annee << "\t" << lt->test_time.heure
		<< "\t" << lt->test_time.minute << "\t" << lt->test_time.seconde << "\n";
}

int resCounter() {
	fstream f("Reservation.csv", ios::in);
	int i = 0;
	while (f) {
		f.ignore(INT_MAX, '\n');
		if (f) {
			i++;
		}
	}
	return i;
}

Labotest* readApp() {
	Labotest* lt = new Labotest[resCounter()];
	fstream f("Reservation.csv", ios::in);
	int i = 0;
	while (f) {
		f >> lt[i].id;
		f.ignore(INT_MAX, ',');
		getline(f, lt[i].fname, ',');
		getline(f, lt[i].lname, ',');
		f >> lt[i].test_date.jour;
		f.ignore(INT_MAX, '-');
		f >> lt[i].test_date.mois;
		f.ignore(INT_MAX, '-');
		f >> lt[i].test_date.annee;
		f.ignore(INT_MAX, ',');
		f >> lt[i].test_time.heure;
		f.ignore(INT_MAX, ':');
		f >> lt[i].test_time.minute;
		f.ignore(INT_MAX, ':');
		f >> lt[i].test_time.seconde;
		f.ignore(INT_MAX, '\n');
		i++;
	}
	return lt;
}

void specificApp(string fname, string lname) {
	Labotest* t = readApp();
	for (int i = 0; i < resCounter(); i++) {
		if (t[i].fname == fname  && t[i].lname == lname) {
			displayApp(t + i);
		}
	}
}

Labotest* deleteSpecApp(string fname, string lname, int day , int id) {
	Labotest* t = readApp();
	Labotest* clean = new Labotest[resCounter()];
	int cleanPos = 0;
	for (int i = 0; i < resCounter(); i++) {
		if (t[i].fname != fname && t[i].lname != lname && t[i].id != id && t[i].test_date.jour != day ) {
			clean[cleanPos] = t[i];
		}
	}
	return clean;
}

void cleanResFile() {
	fstream f("Reservation.csv", ios::out);
	f << "";
}
