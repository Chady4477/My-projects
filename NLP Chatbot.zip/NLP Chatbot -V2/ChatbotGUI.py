import tkinter as tk
from Model import predict_intent, NeuralNet, all_words, tags
import torch

class ChatbotGUI:
    def __init__(self, master):
        self.master = master
        master.title("Chatbot")
        master.configure(background="#F0F0F0")

        # In this code, the ChatbotGUI class is defined, which is expected 
        # to be instantiated with a master argument representing the root 
        # window of the GUI. Inside the __init__ method, the master argument 
        # is assigned to self.master, allowing it to be accessed by other 
        # methods within the class.
        
        
        # Create the widgets
        self.icon = tk.PhotoImage(file="chatbot_icon.png")
        master.iconphoto(False, self.icon)

        self.conversation = tk.Text(master, width=60, height=20, font=("Helvetica", 14), bg="#FFFFFF", fg="#000000")
        self.conversation.pack(padx=10, pady=10)

        self.entry = tk.Entry(master, width=50, font=("Helvetica", 14), bg="#FFFFFF", fg="#000000")
        self.entry.pack(side=tk.LEFT, padx=10, pady=10)

        self.button = tk.Button(master, text="Send", font=("Helvetica", 14), command=self.send_message, bg="#4CAF50", fg="white", padx=20, pady=10)
        self.button.pack(side=tk.LEFT, pady=10)

        # Create a separator to divide the chat area from the input area
        separator = tk.Frame(height=2, bd=1, relief=tk.SUNKEN, bg="#DADADA")
        separator.pack(fill=tk.X, padx=5, pady=5)

        # Load the trained model
        self.model = NeuralNet(len(all_words), 16, len(tags))
        self.model.load_state_dict(torch.load("model.pth"))
        self.model.eval()

    def send_message(self):
        # Get the user's message and clear the input field
        message = self.entry.get()
        self.entry.delete(0, tk.END)

        # Get the predicted intent and display it in the conversation area
        intent = predict_intent(self.model, message)
        self.conversation.insert(tk.END, f"You: {message}\n", "me")
        self.conversation.insert(tk.END, f"Bot: {intent}\n", "bot")
        self.conversation.insert(tk.END, "\n", "bot")
        
# Create the GUI window
root = tk.Tk()
chatbot_gui = ChatbotGUI(root)

# Set up the styles for the conversation area
chatbot_gui.conversation.tag_configure("me", foreground="#0B7F95", font=("Helvetica", 14, "bold"))
chatbot_gui.conversation.tag_configure("bot", foreground="#666666", font=("Helvetica", 14))

# Start the event loop
root.mainloop()
