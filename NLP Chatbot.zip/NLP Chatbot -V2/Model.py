#importing libraries
import numpy as np
import pandas as pd
import tensorflow as tf
import nltk
import json
import torch
from nltk.stem import WordNetLemmatizer

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import Dataset, DataLoader
from torch import nn

#Ali
#importing data
df = pd.read_json('Data.json')

with open('Data.json', 'r') as f:
    intents = json.load(f)

all_words = []
tags = []
xy = []

#Chady
# loop through each sentence in the intents patterns
for intent in intents['intents']:
    tag = intent['tag']
    tags.append(tag)
    for pattern in intent['patterns']:
        # tokenize each word in the sentence
        words = nltk.word_tokenize(pattern)
        # add to our words list
        all_words.extend(words)
        # add to xy pair
        xy.append((words, tag))
 
# This loop iterates over each "intent" in the "intents" list 
# from the loaded JSON data. For each intent, it extracts the "tag" 
# associated with it and appends it to the tags list. Then, it loops
# through each "pattern" within the intent and tokenizes the sentence using
# nltk.word_tokenize(), which splits the sentence into a list of individual
# words. These words are then added to the all_words list, and a tuple 
# (words, tag) is appended to the xy list. This xy list will store pairs
# of tokenized words and their corresponding tags.        
        
#Ali
lemmatizer = WordNetLemmatizer()
# perform lemmatization and lower each word as well as remove duplicates
ignore_words = ['?', '.', ',', '!']
all_words = [lemmatizer.lemmatize(w.lower()) for w in all_words if w not in ignore_words]
all_words = sorted(list(set(all_words)))
tags = sorted(list(set(tags)))

# The code then performs lemmatization and lowercasing on each word 
# in the all_words list, excluding the words present in the ignore_words 
# list. The resulting lemmatized and lowercased words are stored back into 
# the all_words list. Duplicates are removed from the list using set(), 
# and then the list is sorted.
# Similarly, the tags list is sorted and duplicates are removed using set().

#Chady
# create bag of words
bag_of_words = []
for i in range(len(xy)):
    bag = []
    pattern_words = xy[i][0]
    pattern_words = [lemmatizer.lemmatize(word.lower()) for word in pattern_words]
    for word in all_words:
        bag.append(1) if word in pattern_words else bag.append(0)
    bag_of_words.append(bag)

bag_of_words = np.array(bag_of_words)

# The code creates a "bag of words" by creating a list of sentences and then 
# going through each one, creating a bag for the words in the sentence. The words
# are lemmatized and checked against a list of all words, with a 1 or 0 added 
# to the bag to indicate whether the word is present or not. The bags for each 
# sentence are then put into a "bag of words" table, with each row representing 
# a sentence and each column representing a word, and the numbers indicating 
# whether the word is present or not in the sentence. This allows sentences to 
# be represented using numbers based on the presence or absence of specific words.

#Ali
# Define the neural network model
class NeuralNet(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(NeuralNet, self).__init__()
        self.layer1 = nn.Linear(input_size, hidden_size)
        self.layer2 = nn.Linear(hidden_size, hidden_size)
        self.layer3 = nn.Linear(hidden_size, num_classes)
        self.relu = nn.ReLU() #activation function 

# This code defines a class called NeuralNet that inherits from the nn.Module
# class in PyTorch, which is a base class for neural network modules. 
# The constructor, init method, takes in three parameters: input_size, which 
# refers to the size or dimension of the input to the neural network, hidden_size,
# which refers to the number of units in the hidden layer(s) of the neural network, 
# and num_classes, which refers to the number of output classes for the neural network.    
    
#Chady    
    def forward(self, x):
        out = self.layer1(x)
        out = self.relu(out)
        out = self.layer2(out)
        out = self.relu(out)
        out = self.layer3(out)
        return out

# The forward method defines the forward pass of the neural network. 
# It takes an input x and performs the computations required to obtain the output.
# In this case, the input x is passed through the layers of the neural network 
# in a sequential manner:
# x is passed through self.layer1, and the result is stored in out.
# out is passed through the ReLU activation function self.relu, and the 
# result is stored back in out.
# out is then passed through self.layer2, followed by another ReLU activation.
# Finally, out is passed through self.layer3 to obtain the final output.

#Ali
# Set the hyperparameters for training the model
input_size = len(bag_of_words[0])
hidden_size = 16
num_classes = len(tags)
learning_rate = 0.001
num_epochs = 1000

# input_size is set to the length of the first element in the bag_of_words list. 
# It represents the size (dimension) of the input to the neural network. 
# In this case, it is the number of features or words in the bag-of-words representation.
# hidden_size is set to 16. It represents the number of units in the hidden 
# layer(s) of the neural network. This parameter determines the capacity and
# complexity of the neural network.
# num_classes is set to the length of the tags list. It represents the number
# of output classes for the neural network. In this case, it is the number of
# distinct tags or intents in the dataset.
# learning_rate is set to 0.001. It determines the step size at each 
# iteration during the training process. It controls how quickly or slowly
# the model learns from the training data.
# num_epochs is set to 1000. It represents the number of times the entire 
# dataset will be passed forward and backward through the neural network 
# during the training process. Each pass through the dataset is called an epoch.

#Chady
# Convert the dataset to PyTorch tensors
X = torch.from_numpy(bag_of_words).float()
y = torch.zeros(len(xy), num_classes)
for i, item in enumerate(xy):
    label = item[1]
    y[i][tags.index(label)] = 1

# This is a method for teaching a model by creating a "bag of words" list to 
# keep track of words, checking if each word is present in each sentence, and 
# writing down a "1" or "0" for each word in the sentence. The "1"s and "0"s 
# are then put into a numpy array called "bag_of_words," which is used to 
# teach the model. 
# Another table called "y" is created to tell the model 
# what each sentence means or what category it belongs to, and a "1" is put in 
# the column that corresponds to the category of the sentence, with all other 
# columns having "0" because the sentence doesn't belong to those categories

#Ali
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# The train_test_split function takes four arguments:
# X: The input data (bag-of-words representation).
# y: The target labels (one-hot encoded).
# test_size: The proportion of the data to be allocated for testing. 
# In this case, it is set to 0.2, which means 20% of the data will be used 
# for testing, and the remaining 80% will be used for training.
# random_state: The random seed used for shuffling and splitting the data. 
# It ensures that the data is split in a consistent way, allowing for 
# reproducibility of results.
# The function returns four sets of data:
# X_train: The training set of input data.
# X_test: The testing set of input data.
# y_train: The training set of target labels.
# y_test: The testing set of target labels.
# By splitting the data into training and testing sets, it allows for 
# evaluating the performance of the trained model on unseen data. The training
# set (X_train and y_train) is used to train the neural network model, 
# and the testing set (X_test and y_test) is used to evaluate its performance 
# and generalization ability.

#Chady
# Define the model, loss function and optimizer
model = NeuralNet(input_size, hidden_size, num_classes)
criterion = nn.CrossEntropyLoss() #loss function
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# An instance of the NeuralNet class, which was defined earlier, is created. 
# The constructor of the NeuralNet class is called with the input_size, 
# hidden_size, and num_classes parameters to initialize the neural network model.
# The nn.CrossEntropyLoss() function is used to define the loss function. 
# Cross-entropy loss is commonly used for classification tasks, where 
# the model predicts class probabilities. It combines a softmax activation 
# function and the negative log-likelihood loss.
# The torch.optim.Adam() function is used to define the optimizer. 
# Adam (Adaptive Moment Estimation) is an optimization algorithm that is 
# widely used for training neural networks. It adapts the learning rate for 
# each parameter based on the first and second moments of the gradients. 
# The optimizer is initialized with the parameters of the model using 
# model.parameters() and the learning_rate hyperparameter.

#Ali
# Train the model
for epoch in range(num_epochs):
    # Forward pass and loss calculation
    outputs = model(X_train)
    loss = criterion(outputs, torch.max(y_train, 1)[1])

    # The loop iterates over the range of num_epochs, which represents the 
    # number of times the entire dataset will be passed through the model 
    # during training.
    # Inside the loop, the forward pass is performed by passing the training 
    # input X_train through the model. The output predictions are stored in 
    # the outputs variable.
    # The loss is calculated by comparing the predicted outputs with the 
    # ground truth labels (y_train) using the criterion (cross-entropy loss) 
    # defined earlier.
    
#Chady    
    # Backward and optimize
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    # The optimizer's gradient is reset to zero using optimizer.zero_grad()
    # to clear any accumulated gradients from the previous iteration.
    #The gradients are computed by calling loss.backward() to perform 
    # backpropagation, calculating the gradients of the model's parameters 
    # with respect to the loss.
    # The optimizer's step() method is called to update the model's parameters
    # based on the computed gradients and the learning rate.
    #Gradients are values that indicate the direction and magnitude of adjustments to be made to the parameters during the training process.

#ali
    # Print the loss at every 100th epoch
    if (epoch+1) % 100 == 0:
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}")

    # At every 100th epoch (e.g., when (epoch+1) % 100 == 0), the loss 
    # is printed using print(f"Epoch [{epoch+1}/{num_epochs}], 
    # Loss: {loss.item():.4f}"). The loss.item() method is used to 
    # retrieve the numerical value of the loss.
    
#Chady
#Evaluate the model's performance on the testing set
with torch.no_grad():
    outputs = model(X_test)
    _, predicted = torch.max(outputs.data, 1)
    accuracy = (predicted == torch.max(y_test, 1)[1]).sum().item() / len(y_test)
    print(f"Accuracy: {accuracy:.4f}")

# The with torch.no_grad() context manager is used to disable gradient 
# calculation during the evaluation phase. This speeds up computation and 
# reduces memory usage since gradients are not needed for evaluation.
# The testing input X_test is passed through the trained model to obtain 
# the output predictions in the outputs variable.
# The torch.max() function is used to get the predicted class indices by 
# taking the maximum value along the second dimension (1) of the outputs.data 
# tensor. The predicted class indices are stored in the predicted variable.
# The accuracy is calculated by comparing the predicted class indices with 
# the ground truth labels (y_test). The comparison 
# (predicted == torch.max(y_test, 1)[1]) creates a tensor of Boolean values 
# indicating whether the predicted and ground truth labels match.The .sum().item() 
# part sums up the number of correct predictions (where the Boolean value is 
# True), and .item() converts it to a numerical value.The accuracy value is 
# then divided by the length of y_test (the number of samples in the testing 
# set) to get the accuracy percentage.Finally, the accuracy is printed using
# print(f"Accuracy: {accuracy:.4f}"), where accuracy:.4f formats the accuracy 
# value to four decimal places.

#Ali
#Save the trained model
torch.save(model.state_dict(), "model.pth")

# The model.state_dict() function returns a dictionary containing the state
# of the trained model's parameters.
# The torch.save() function is used to save the model's state dictionary 
# to a file named "model.pth". The file extension ".pth" is commonly used 
# to indicate PyTorch model checkpoints.

#ali
#function to predict the intent of a user's message
def predict_intent(model, sentence):
    # Tokenize the user's message
    words = nltk.word_tokenize(sentence)
    # Perform lemmatization and lower each word
    words = [lemmatizer.lemmatize(word.lower()) for word in words]
    # Convert the tokenized message to a bag of words
    bag = np.zeros(len(all_words), dtype=np.float32)
    for word in words:
        for i, w in enumerate(all_words):
            if w == word:
                bag[i] = 1
                
    # This code correctly tokenizes the user's message using 
    # nltk.word_tokenize(), performs lemmatization and lowercasing 
    # on each word, and converts the tokenized message into a bag-of-words
    # representation using a loop that checks if each word in words is 
    # present in all_words and sets the corresponding entry in bag accordingly.            
    
#Chady
    # Make a prediction with the trained model
    input_tensor = torch.from_numpy(bag).unsqueeze(0)
    outputs = model(input_tensor)
    _, predicted = torch.max(outputs.data, 1)
    tag = tags[predicted.item()]
    
    # In this code, the bag-of-words representation stored in the bag variable
    # is converted to a PyTorch tensor using torch.from_numpy(bag). 
    # The .unsqueeze(0) function adds an extra dimension to the tensor to 
    # match the expected input shape of the model.
    # The input tensor is then passed to the trained model using model(input_tensor), 
    # which returns the output tensor containing the model's predictions
    # for each class. The torch.max(outputs.data, 1) function is used to obtain 
    # the predicted class index.
    
#Chady    
    # Find the appropriate response based on the predicted tag
    for intent in intents['intents']:
        if intent['tag'] == tag:
            responses = intent['responses']
    
    return np.random.choice(responses)
    
    # In this code, a loop iterates over each intent in the intents dictionary. 
    # For each intent, it checks if the tag matches the predicted tag obtained
    # earlier. If there is a match, the list of responses for that intent is 
    # assigned to the responses variable. 
    # After the loop, the function uses np.random.choice(responses) to
    # randomly select one response from the list of responses.
    # Finally, the randomly chosen response is returned as the output 
    # of the function.
    